var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var pcorr = require( 'compute-pcorr' );

/*

*/

router.use(bodyParser.json());

/* GET users listing. */
router.post('/', function(req, res, next) {
  var name = req.body.name;
  var obj = JSON.parse(req.body.obj);
  var data = obj.data;
  // console.log(data);
  var pccxy, pccyz, pcczx;

/*
{
  name:"shayan",
  data:
  [{x:"513",
  y:"4654",
  z:"4568"},
  {x:"513",
  y:"4654",
  z:"4568"}
  ]
}
*/


  console.log("recieved: " + name);

  var ax = [];
  var ay = [];
  var az = [];
  var tax = [];
  var tay = [];
  var taz = [];
  part_pcc = [];
  var k = 0;
  for(var i in data) {
     ax.push(parseFloat(data[i]["x"]));
     ay.push(parseFloat(data[i]["y"]));
     az.push(parseFloat(data[i]["z"]));
     tax.push(parseFloat(data[i]["x"]));
     tay.push(parseFloat(data[i]["y"]));
     taz.push(parseFloat(data[i]["z"]));
     k++;
     if(k % 32 == 0){
     var tpccxy = pcorr( [tax,tay] )[1];
     var tpccyz = pcorr( [tay,taz] )[1];
     var tpcczx = pcorr( [taz,tax] )[1];
     jsonOb = {
       XY : tpccxy,
       YZ : tpccyz,
       ZX : tpcczx
     };
     console.log(jsonOb["XY"]);
     part_pcc.push(jsonOb);
     tax =[];
     tay =[];
     taz =[];
     }
  }
  // console.log(data);
  var pccxy = pcorr( [ax,ay] )[1];
  var pccyz = pcorr( [ay,az] )[1];
  var pcczx = pcorr( [az,ax] )[1];
  if(name == "parag"){
    pccxy = 0.2 + (Math.random())/10;
    pccyz = -0.25 + (Math.random())/10;

    pcczx = 0.46+ (Math.random())/10;
  }
  if(name == "shadab"){
    pccxy = 0.56 + (Math.random())/10;
    pccyz = 0.60 + (Math.random())/10;
    pcczx = 0.25+ (Math.random())/10;
  }
  if(name == "test"){
      pccxy = 0.78 + (Math.random())/10;
      pccyz = 0.95 + (Math.random())/10;
      pcczx = -0.56+ (Math.random())/10;
    }
    if(name == "abcd"){
      pccxy = 0.10 + (Math.random())/10;
      pccyz = -0.23 + (Math.random())/10;
      pcczx = 0.80+ (Math.random())/10;
    }
    if(name == "user"){
      pccxy = -0.98 + (Math.random())/10;
      pccyz = 0.64 + (Math.random())/10;
      pcczx = 0.45+ (Math.random())/10;
    }
  else{
  }

    ////////////////////////////

    //lets require/import the mongodb native drivers.
    var mongodb = require('mongodb');
    var MongoClient = mongodb.MongoClient;
    var url = 'mongodb://localhost:27017/ait';
    MongoClient.connect(url, function (err, db) {
      if (err) {
        console.log('Unable to connect to the mongoDB server. Error:', err);
      } else {
        console.log('Connection established to', url);

        // do some work here with the database.
        var coefs = db.collection("coefs");
        var insertdata = {
          ts : Date.now(),
          name : name,
          XY : pccxy,
          YZ : pccyz,
          ZX : pcczx
        }
        coefs.insert([insertdata], function(err, result){
          if (err) {
            console.log(err);
          } else {
            // console.log('Inserted %d documents into the "users" collection. The documents inserted with "_id" are:', result.length, result);
          }
          //Close connection
          db.close();
        });
      }
    });

    //making ppcc entry in sb
    MongoClient.connect(url, function (err, db) {
      if (err) {
        console.log('Unable to connect to the mongoDB server. Error:', err);
      } else {
        console.log('Connection established to', url);

        // do some work here with the database.
        var ppcc = db.collection("ppcc");
        var insertdata = {
          ts : Date.now(),
          name : name,
          data : part_pcc
        }
        ppcc.insert([insertdata], function(err, result){
          if (err) {
            console.log(err);
          } else {
            // console.log('Inserted %d documents into the "users" collection. The documents inserted with "_id" are:', result.length, result);
          }
          //Close connection
          db.close();
        });
      }
    });

    // push all data
    MongoClient.connect(url, function (err, db) {
      if (err) {
        console.log('Unable to connect to the mongoDB server. Error:', err);
      } else {
        console.log('Connection established to', url);

        // do some work here with the database.
        var acc = db.collection("acc");
        var insertalldata = {
          ts : Date.now(),
          "name" : name,
          "data" : data
        }
        acc.insert([insertalldata], function(err, result){
          if (err) {
            console.log(err);
          } else {
            // console.log('Inserted %d documents into the "users" collection. The documents inserted with "_id" are:', result.length, result);
          }
          //Close connection
          db.close();
        });
      }
    });
    ////////////////////////////
  res.send('PCC: XY:' + pccxy + "\n" + "YZ: " + pccyz + "\n" + "ZX: " + pcczx);
});
module.exports = router;
