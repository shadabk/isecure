var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var pcorr = require( 'compute-pcorr' );

/*
{
  name:"shadab",
  obj:{
    name:"shadab",
    data:[1,2,3,4]
  }
}

*/

router.use(bodyParser.json());

/* GET users listing. */
router.post('/', function(req, res, next) {
  var name = req.body.name;
  var obj = JSON.parse(req.body.obj);
  var data = obj.data;
  // console.log(data);
  var x = [];

  for(var i in data) {
     x.push(parseFloat(data[i]));
  }
  x = JSON.parse(x);
  res.json(x);
});
module.exports = router;
